@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ============================================================
echo LOCALAI STUDIO - FULL PROJECT DIAGNOSTIC
echo This is a read-only inspection. No models or user files deleted.
echo ============================================================
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Diagnose-Full.ps1"
if errorlevel 1 (
  echo.
  echo Diagnostic runner returned an error. Check DIAGNOSTIC-OUTPUT-*.
)
echo.
