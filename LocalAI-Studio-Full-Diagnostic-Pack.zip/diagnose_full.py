from __future__ import annotations
import argparse, ast, compileall, contextlib, datetime as dt, importlib.metadata as md
import importlib.util, json, os, platform, re, shutil, socket, sqlite3, subprocess
import sys, tempfile, threading, time, traceback, urllib.error, urllib.request, zipfile
from pathlib import Path
from html.parser import HTMLParser

SECRET_PATTERNS = [
    (re.compile(r'(?i)(api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|passwd|authorization)\s*([:=]\s*)([^\s,;]+)'), r'\1\2[REDACTED]'),
    (re.compile(r'''(?i)([\"'](?:api[_-]?key|token|secret|password|authorization)[\"']\s*:\s*[\"'])(.*?)([\"'])'''), r'\1[REDACTED]\3'),
    (re.compile(r'(?i)Bearer\s+[A-Za-z0-9._~+/=-]{12,}'), 'Bearer [REDACTED]'),
    (re.compile(r'(?i)(sk-[A-Za-z0-9_-]{16,})'), '[REDACTED_API_TOKEN]'),
    (re.compile(r'(?i)(hf_[A-Za-z0-9]{16,})'), '[REDACTED_HF_TOKEN]'),
    (re.compile(r'(?i)(ltx[_-]?[A-Za-z0-9_-]{16,})'), '[REDACTED_PROVIDER_TOKEN]'),
    (re.compile(r'(?i)(https?://[^\s/:]+:[^\s/@]+@)'), 'https://[REDACTED]@'),
]
USER_PATH_RE = re.compile(r'(?i)([A-Z]:\\Users\\)[^\\]+')

def redact(value: object) -> str:
    s = str(value)
    for pattern, replacement in SECRET_PATTERNS:
        s = pattern.sub(replacement, s)
    s = USER_PATH_RE.sub(r'\1[USER]', s)
    return s[:1200]

class CheckBook:
    def __init__(self): self.checks=[]; self.errors=[]; self.warnings=[]
    def add(self, name, status, detail=None, severity=None):
        item={"name":name,"status":status}
        if detail is not None: item["detail"]=detail
        self.checks.append(item)
        if status == 'FAIL': self.errors.append(item)
        elif status == 'WARN': self.warnings.append(item)
    def summary(self):
        return {"total":len(self.checks),"pass":sum(x['status']=='PASS' for x in self.checks),"warn":len(self.warnings),"fail":len(self.errors)}

class MarkupInspector(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.assets=[]
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if a.get('id'): self.ids.append(a['id'])
        if tag == 'script' and a.get('src'): self.assets.append(a['src'])
        if tag == 'link' and a.get('href'): self.assets.append(a['href'])


def clean_diagnostic_env(temp: Path) -> dict[str, str]:
    keep = {'PATH','SYSTEMROOT','WINDIR','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA',
            'PROGRAMFILES','PROGRAMFILES(X86)','COMMONPROGRAMFILES','COMSPEC','PATHEXT',
            'PROCESSOR_ARCHITECTURE','NUMBER_OF_PROCESSORS','HOME'}
    env = {k:v for k,v in os.environ.items() if k.upper() in keep}
    env.update({'LOCALAI_NO_BROWSER':'1','OLLAMA_HOST':'http://127.0.0.1:9',
                'HF_HOME':str(temp/'hf'),'OPENVINO_CACHE_DIR':str(temp/'ov-cache'),'PYTHONUTF8':'1'})
    return env


def run_cmd(args, cwd=None, timeout=20, env=None):
    try:
        p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,text=True,errors='replace',shell=False)
        return p.returncode, redact(p.stdout), redact(p.stderr)
    except subprocess.TimeoutExpired as e:
        return 124, redact(e.stdout or ''), 'TIMEOUT after %ss' % timeout
    except Exception as e:
        return 125, '', redact(repr(e))


def check_files(root: Path, b: CheckBook):
    expected = [
        'app.py','Start.ps1','Start-LocalAI.bat','Diagnose.bat','Diagnose.ps1','Runtime-Check.py',
        'templates/index.html','static/js/app.js','static/css/app.css','static/css/experience.css',
        'workers/animatediff_cpu_worker.py','workers/download_animatediff.py',
        '.venv/Scripts/python.exe','models','outputs','inputs','videos','cache','logs'
    ]
    for rel in expected:
        p=root/rel
        status='PASS' if p.exists() else ('WARN' if rel in ('static/css/experience.css','workers/animatediff_cpu_worker.py','workers/download_animatediff.py','inputs','cache') else 'FAIL')
        detail='directory' if p.is_dir() else ('file %s bytes' % p.stat().st_size if p.is_file() else 'missing')
        b.add('file:'+rel,status,detail)


def source_checks(root: Path, py: Path, b: CheckBook, out: Path):
    files=[]
    skip={'.venv','models','outputs','inputs','videos','cache','logs','__pycache__','backups','diagnostics','.git'}
    for current, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in skip]
        current_path=Path(current)
        try: depth=len(current_path.relative_to(root).parts)
        except ValueError: depth=99
        if depth > 7:
            dirs[:] = []
            continue
        for name in names:
            if name.lower().endswith('.py'):
                files.append(current_path/name)
    syntax_errors=[]
    for p in files:
        try:
            source=p.read_text(encoding='utf-8-sig')
            compile(source,str(p),'exec')
        except Exception as e:
            syntax_errors.append({'file':str(p.relative_to(root)),'error':redact(e)})
    b.add('python_source_syntax','FAIL' if syntax_errors else 'PASS',syntax_errors if syntax_errors else {'files_checked':len(files)})
    rc, stdout, stderr=run_cmd([str(py),'-m','pip','check'],cwd=str(root),timeout=90)
    b.add('pip_dependency_consistency','PASS' if rc==0 else 'FAIL',{'exit_code':rc,'stdout':stdout[-4000:],'stderr':stderr[-3000:]})
    # Capture package versions without dumping environment variables.
    code="import importlib.metadata as m, json; names=['Flask','Pillow','Werkzeug','waitress','openvino','optimum-intel','diffusers','transformers','torch','psutil','imageio-ffmpeg']; print(json.dumps({n:(m.version(n) if any(d.metadata['Name'].lower()==n.lower() for d in m.distributions()) else None) for n in names}))"
    rc, stdout, stderr=run_cmd([str(py),'-c',code],cwd=str(root),timeout=30)
    try: packages=json.loads(stdout.strip().splitlines()[-1])
    except Exception: packages={'parse_error':stdout,'stderr':stderr,'exit_code':rc}
    b.add('python_package_inventory','PASS' if rc==0 else 'WARN',packages)
    # Node syntax validation when available.
    node=shutil.which('node')
    js=root/'static/js/app.js'
    if node and js.is_file():
        rc, so, se=run_cmd([node,'--check',str(js)],cwd=str(root),timeout=30)
        b.add('javascript_syntax','PASS' if rc==0 else 'FAIL',{'exit_code':rc,'stdout':so,'stderr':se})
    elif js.is_file(): b.add('javascript_syntax','WARN','Node.js not installed; JavaScript runtime parse was not independently checked.')
    else: b.add('javascript_syntax','FAIL','static/js/app.js is missing.')
    # HTML assets and IDs
    html=root/'templates/index.html'
    if html.is_file():
        try:
            inspector=MarkupInspector(); inspector.feed(html.read_text(encoding='utf-8-sig'))
            duplicate=sorted({x for x in inspector.ids if inspector.ids.count(x)>1})
            missing=[]
            for asset in inspector.assets:
                if asset.startswith(('http://','https://','data:','#','//')): continue
                clean=asset.split('?',1)[0].split('#',1)[0].lstrip('/')
                if clean.startswith('static/'): target=root/clean
                else: continue
                if not target.is_file(): missing.append(asset)
            b.add('html_markup_assets','FAIL' if missing else ('WARN' if duplicate else 'PASS'),{'element_ids':len(inspector.ids),'duplicate_ids':duplicate[:80],'missing_assets':missing})
            # IDs referenced literally by JS; exclude dynamic expressions as only literal matches are considered.
            js_text=js.read_text(encoding='utf-8-sig') if js.is_file() else ''
            refs=set(re.findall(r"(?:getElementById|querySelector)\(\s*['\"]#?([A-Za-z][A-Za-z0-9_:-]*)['\"]\s*\)",js_text))
            idset=set(inspector.ids)
            missing_refs=sorted(refs-idset)
            b.add('javascript_dom_references','WARN' if missing_refs else 'PASS',{'literal_ids_referenced':len(refs),'not_in_html':missing_refs[:120]})
        except Exception as e: b.add('html_markup_assets','FAIL',redact(traceback.format_exc()))
    else: b.add('html_markup_assets','FAIL','templates/index.html missing')
    # CSS rough lexical sanity: braces and file emptiness.
    for rel in ('static/css/app.css','static/css/experience.css'):
        p=root/rel
        if p.is_file():
            txt=p.read_text(encoding='utf-8-sig',errors='replace')
            opens=txt.count('{'); closes=txt.count('}')
            b.add('css:'+rel,'PASS' if opens==closes and opens>0 else 'WARN',{'bytes':p.stat().st_size,'opening_braces':opens,'closing_braces':closes})


def app_test_client(root: Path, py: Path, b: CheckBook, out: Path):
    required=['app.py','templates/index.html','static']
    missing=[x for x in required if not (root/x).exists()]
    if missing:
        b.add('flask_test_client','FAIL',{'missing':missing}); return
    with tempfile.TemporaryDirectory(prefix='LocalAIStudio-Diag-') as td:
        temp=Path(td)
        shutil.copy2(root/'app.py',temp/'app.py')
        shutil.copytree(root/'templates',temp/'templates')
        shutil.copytree(root/'static',temp/'static')
        if (root/'workers').is_dir(): shutil.copytree(root/'workers',temp/'workers')
        env=clean_diagnostic_env(temp)
        code=r'''import importlib.util,json,sys
from pathlib import Path
root=Path.cwd(); spec=importlib.util.spec_from_file_location("diag_app",root/"app.py"); m=importlib.util.module_from_spec(spec); sys.modules[spec.name]=m; spec.loader.exec_module(m)
c=m.app.test_client(); pages=['/','/dashboard','/create','/queue','/motion','/gallery','/models','/settings']; results={}
for p in pages:
 r=c.get(p); results[p]=r.status_code
 if r.status_code!=200: raise RuntimeError(f'{p}: HTTP {r.status_code}')
 if p=='/create' and b'id="page-create"' not in r.data and b"id='page-create'" not in r.data: raise RuntimeError('/create missing page-create marker')
for p in ['/healthz','/api/paths','/api/status','/api/models','/api/settings','/api/queue','/api/active','/api/gallery','/api/video/local/status','/api/video/provider','/api/ai/status']:
 r=c.get(p); results[p]=r.status_code
 if r.status_code>=500: raise RuntimeError(f'{p}: HTTP {r.status_code}')
for p in ['/static/js/app.js','/static/css/app.css']:
 r=c.get(p); results[p]=r.status_code
 if r.status_code!=200: raise RuntimeError(f'{p}: HTTP {r.status_code}')
print(json.dumps({'routes':results,'flask_url_map':[str(x) for x in m.app.url_map.iter_rules()]},ensure_ascii=False))'''
        rc, so, se=run_cmd([str(py),'-c',code],cwd=str(temp),timeout=75,env=env)
        if rc==0:
            try: detail=json.loads(so.strip().splitlines()[-1])
            except Exception: detail={'stdout':so[-5000:]}
            b.add('flask_isolated_test_client','PASS',detail)
        else: b.add('flask_isolated_test_client','FAIL',{'exit_code':rc,'stdout':so[-5000:],'stderr':se[-5000:]})


def actual_tcp_smoke(root: Path, py: Path, b: CheckBook, out: Path):
    needed=['app.py','templates/index.html','static']
    if not all((root/x).exists() for x in needed):
        b.add('isolated_real_tcp_server','SKIP','Core app files missing.'); return
    with tempfile.TemporaryDirectory(prefix='LocalAIStudio-TCP-Diag-') as td:
        temp=Path(td)
        shutil.copy2(root/'app.py',temp/'app.py'); shutil.copytree(root/'templates',temp/'templates'); shutil.copytree(root/'static',temp/'static')
        if (root/'workers').is_dir(): shutil.copytree(root/'workers',temp/'workers')
        # Reserve an ephemeral localhost port, then launch a copied app with an isolated DB/storage root.
        sock=socket.socket(); sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]; sock.close()
        env=clean_diagnostic_env(temp); env['LOCALAI_PORT']=str(port)
        outlog=temp/'server.stdout.log'; errlog=temp/'server.stderr.log'
        proc=None; details={}
        try:
            with outlog.open('w',encoding='utf-8',errors='replace') as so, errlog.open('w',encoding='utf-8',errors='replace') as se:
                proc=subprocess.Popen([str(py),'-u','app.py'],cwd=str(temp),env=env,stdout=so,stderr=se)
                base=f'http://127.0.0.1:{port}'
                ready=False; last_error=''
                for _ in range(50):
                    if proc.poll() is not None: break
                    try:
                        with urllib.request.urlopen(base+'/healthz',timeout=1.5) as resp:
                            data=json.loads(resp.read().decode('utf-8','replace'))
                            if resp.status==200 and data.get('ok') is True: ready=True; break
                    except Exception as e: last_error=repr(e)
                    time.sleep(.3)
                if not ready:
                    details={'ready':False,'process_exit':proc.poll(),'last_error':redact(last_error)}
                else:
                    route_results={}
                    routes=['/','/dashboard','/create','/queue','/motion','/gallery','/models','/settings','/static/js/app.js','/static/css/app.css','/static/css/experience.css','/healthz','/api/paths']
                    for route in routes:
                        try:
                            with urllib.request.urlopen(base+route,timeout=5) as resp:
                                body=resp.read()
                                route_results[route]={'status':resp.status,'bytes':len(body)}
                                if route=='/create' and b'id=\"page-create\"' not in body and b"id='page-create'" not in body:
                                    route_results[route]['page_marker']='missing'
                        except urllib.error.HTTPError as e: route_results[route]={'status':e.code}
                        except Exception as e: route_results[route]={'error':redact(repr(e))}
                    bad={k:v for k,v in route_results.items() if v.get('status')!=200 or v.get('page_marker')=='missing' or 'error' in v}
                    details={'ready':True,'port':port,'routes':route_results,'failed_routes':bad}
                    # Optional real browser render: headless Edge/Chrome loads /create and executes its JS.
                    browser_candidates=[]
                    for exe in ('msedge','chrome','chromium','chromium-browser'):
                        found=shutil.which(exe)
                        if found: browser_candidates.append(found)
                    if os.name=='nt':
                        for base_dir in (os.environ.get('ProgramFiles',''),os.environ.get('PROGRAMFILES(X86)',''),os.environ.get('LOCALAPPDATA','')):
                            if base_dir:
                                browser_candidates.extend([str(Path(base_dir)/'Microsoft/Edge/Application/msedge.exe'),str(Path(base_dir)/'Google/Chrome/Application/chrome.exe')])
                    browser=next((x for x in browser_candidates if Path(x).is_file()),None)
                    if browser:
                        profile=temp/'browser-profile'
                        rc, dom, browser_err=run_cmd([browser,'--headless=new','--disable-gpu','--no-first-run','--disable-background-networking','--disable-extensions','--disable-sync','--no-default-browser-check','--enable-logging=stderr','--user-data-dir='+str(profile),'--virtual-time-budget=7000','--dump-dom',base+'/create'],cwd=str(temp),timeout=30,env=env)
                        marker=('id=\"page-create\"' in dom or "id='page-create'" in dom)
                        details['headless_browser']={'browser':Path(browser).name,'exit_code':rc,'creation_marker_found':marker,'dom_bytes':len(dom),'stderr':browser_err[-3500:]}
                        if rc!=0 or not marker: details['failed_routes']['headless_browser']=details['headless_browser']
                    else:
                        details['headless_browser']={'status':'SKIP','reason':'Edge/Chrome executable not found'}
        except Exception as e: details={'exception':redact(traceback.format_exc())}
        finally:
            if proc is not None and proc.poll() is None:
                try: proc.terminate(); proc.wait(timeout=6)
                except Exception:
                    try: proc.kill(); proc.wait(timeout=3)
                    except Exception: pass
        for lf in (outlog,errlog):
            if lf.exists() and lf.stat().st_size:
                details[lf.name]=redact(lf.read_text(encoding='utf-8',errors='replace')[-5000:])
        ok=details.get('ready') and not details.get('failed_routes')
        b.add('isolated_real_tcp_server','PASS' if ok else 'FAIL',details)


def database_check(root: Path, b: CheckBook):
    candidates=[]
    for name in ('studio.sqlite3','studio.db','queue.sqlite3','localai.db'):
        p=root/name
        if p.is_file(): candidates.append(p)
    for p in root.glob('*.sqlite*'):
        if p.is_file() and p not in candidates: candidates.append(p)
    if not candidates:
        b.add('database_integrity','WARN','No known SQLite database file found.'); return
    for dbp in candidates:
        try:
            uri=dbp.resolve().as_uri()+'?mode=ro'
            con=sqlite3.connect(uri,uri=True,timeout=4)
            quick=con.execute('PRAGMA quick_check').fetchone()[0]
            tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            counts={}
            for t in tables:
                if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',t):
                    try: counts[t]=con.execute('SELECT COUNT(*) FROM "'+t+'"').fetchone()[0]
                    except Exception: counts[t]='unavailable'
            con.close()
            b.add('database_integrity:'+dbp.name,'PASS' if quick=='ok' else 'FAIL',{'quick_check':quick,'tables':tables,'row_counts_only':counts,'bytes':dbp.stat().st_size})
        except Exception as e: b.add('database_integrity:'+dbp.name,'WARN',redact(e))


def model_checks(root: Path, b: CheckBook):
    models=root/'models'
    expected={
      'LCM_Dreamshaper_v7-int8-ov':'DreamShaper LCM',
      'stable-diffusion-v1-5-int8-ov':'Stable Diffusion 1.5 INT8',
      'stable-diffusion-xl-base-1.0-int8-ov':'SDXL INT8',
      'animatediff-lightning':'AnimateDiff-Lightning',
      'community-openvino-models/image/SSD-1B/int8':'SSD-1B INT8 community conversion',
    }
    for folder,label in expected.items():
        p=models/folder
        if p.exists():
            count=sum(1 for x in p.rglob('*') if x.is_file())
            total=sum(x.stat().st_size for x in p.rglob('*') if x.is_file())
            status='PASS' if count>0 else 'WARN'
            b.add('model:'+label,status,{'folder':folder,'file_count':count,'size_gb':round(total/1024**3,3)})
        else: b.add('model:'+label,'WARN','Not downloaded; does not prevent app startup.')
    video=root/'models/animatediff-lightning'
    if video.exists():
        checks=[video/'base/model_index.json',video/'adapter/animatediff_lightning_4step_diffusers.safetensors']
        b.add('animatediff_model_completeness','PASS' if all(x.is_file() for x in checks) else 'WARN',{'required_files':{str(x.relative_to(root)):x.is_file() for x in checks}})
    venv=root/'.video-venv/Scripts/python.exe'
    b.add('animatediff_video_environment','PASS' if venv.is_file() else 'WARN','Video-specific Python environment '+('exists' if venv.is_file() else 'not installed'))


def openvino_check(py: Path, root: Path, b: CheckBook, out: Path):
    code="import json; import openvino as ov; c=ov.Core(); print(json.dumps({'version':ov.__version__,'devices':c.available_devices},ensure_ascii=False))"
    rc, so, se=run_cmd([str(py),'-c',code],cwd=str(root),timeout=45)
    if rc==0:
        try: detail=json.loads(so.strip().splitlines()[-1])
        except Exception: detail={'stdout':so,'stderr':se}
        b.add('openvino_runtime_devices','PASS' if detail.get('devices') else 'WARN',detail)
    else: b.add('openvino_runtime_devices','WARN' if 'No module named' in se else 'FAIL',{'exit_code':rc,'stdout':so,'stderr':se})


def ollama_check(b: CheckBook):
    exe=shutil.which('ollama')
    if not exe:
        candidates=[]
        if os.name=='nt':
            candidates=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs/Ollama/ollama.exe',Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Ollama/ollama.exe']
        exe=next((str(x) for x in candidates if x.is_file()),None)
    if not exe: b.add('ollama_cli','WARN','Ollama CLI not found in PATH or common installation paths.'); return
    rc, so, se=run_cmd([exe,'list'],timeout=20)
    b.add('ollama_models','PASS' if rc==0 else 'WARN',{'executable':redact(exe),'exit_code':rc,'model_list':so[-3000:],'stderr':se[-2000:]})
    try:
        with urllib.request.urlopen('http://127.0.0.1:11434/api/version',timeout=2) as r:
            b.add('ollama_server','PASS',json.loads(r.read().decode('utf-8','replace')))
    except Exception as e: b.add('ollama_server','WARN',redact(e))


def config_check(root: Path, b: CheckBook):
    for name in ('settings.json','secrets.json'):
        p=root/name
        if not p.exists(): b.add('config:'+name,'WARN','File missing; application may use defaults.'); continue
        try:
            data=json.loads(p.read_text(encoding='utf-8-sig'))
            # Only report structural properties; never expose values.
            keys=list(data.keys()) if isinstance(data,dict) else []
            key_presence=any('key' in str(k).lower() or 'token' in str(k).lower() for k in keys)
            b.add('config:'+name,'PASS',{'valid_json':True,'top_level_keys':keys[:80],'credential_like_key_present':key_presence,'values':'not collected'})
        except Exception as e: b.add('config:'+name,'FAIL',redact(e))


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out',required=True)
    args=ap.parse_args(); root=Path(args.root).resolve(); out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    b=CheckBook(); py=root/'.venv/Scripts/python.exe'
    if not py.is_file(): py=Path(sys.executable)
    b.add('installation_root','PASS' if (root/'app.py').is_file() else 'FAIL',redact(root))
    b.add('selected_python','PASS',{'executable':redact(py),'version':platform.python_version() if py==Path(sys.executable) else 'venv executable selected'})
    check_files(root,b)
    if (root/'app.py').is_file(): source_checks(root,py,b,out)
    else: b.add('source_checks','SKIP','app.py missing')
    if (root/'app.py').is_file():
        app_test_client(root,py,b,out)
        actual_tcp_smoke(root,py,b,out)
    else: b.add('flask_runtime_tests','SKIP','app.py missing')
    database_check(root,b); model_checks(root,b); config_check(root,b); openvino_check(py,root,b,out); ollama_check(b)
    payload={
      'generated_at':dt.datetime.now().astimezone().isoformat(timespec='seconds'),
      'installation_root':redact(root), 'diagnostic_version':'1.0.0',
      'environment':{'platform':platform.platform(),'python_used':redact(py)},
      'summary':b.summary(),'checks':b.checks,
      'privacy':{'secret_values_collected':False,'database_contents_collected':False,'image_video_contents_collected':False,'model_binary_contents_collected':False}
    }
    (out/'project-diagnostic.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['LOCALAI STUDIO - PROJECT DIAGNOSTIC','Generated: '+payload['generated_at'],'Install: '+str(root),'',
      'SUMMARY: {pass} PASS | {warn} WARN | {fail} FAIL'.format(**b.summary()),'']
    for x in b.checks:
        lines.append('[%s] %s' % (x['status'],x['name']))
        if 'detail' in x: lines.append('  '+redact(json.dumps(x['detail'],ensure_ascii=False))[:9000])
    (out/'project-diagnostic.txt').write_text('\n'.join(lines),encoding='utf-8-sig')
    print(json.dumps({'ok':b.summary()['fail']==0,'summary':b.summary(),'report':str(out/'project-diagnostic.txt')},ensure_ascii=False))
    return 0 if b.summary()['fail']==0 else 2

if __name__=='__main__':
    try: raise SystemExit(main())
    except SystemExit: raise
    except Exception:
        print(traceback.format_exc(),file=sys.stderr); raise
