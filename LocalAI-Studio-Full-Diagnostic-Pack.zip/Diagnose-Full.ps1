﻿$ErrorActionPreference = 'Continue'
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$OutDir = Join-Path $PackageRoot ("DIAGNOSTIC-OUTPUT-" + $Stamp)
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$Report = Join-Path $OutDir 'FULL-DIAGNOSTIC-REPORT.txt'
$SystemReport = Join-Path $OutDir 'windows-system-report.txt'
$LogReport = Join-Path $OutDir 'sanitized-log-excerpts.txt'
$PyOut = Join-Path $OutDir 'python-diagnostic.stdout.txt'
$PyErr = Join-Path $OutDir 'python-diagnostic.stderr.txt'
$Lines = New-Object System.Collections.Generic.List[string]
function Add-Line([string]$Text) { $Lines.Add($Text) }
function Safe-Text([string]$Text) {
    if ($null -eq $Text) { return '' }
    $s = $Text
    $s = [regex]::Replace($s, '(?i)(api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|passwd|authorization)(\s*[:=]\s*)([^\s,;]+)', '$1$2[REDACTED]')
    $s = [regex]::Replace($s, '(?i)("?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|token|password|authorization)"?\s*:\s*"?)([^",}\s]+)', '$1[REDACTED]')
    $s = [regex]::Replace($s, '(?i)Bearer\s+[A-Za-z0-9._~+/=-]{12,}', 'Bearer [REDACTED]')
    $s = [regex]::Replace($s, '(?i)sk-[A-Za-z0-9_-]{16,}', '[REDACTED_API_TOKEN]')
    $s = [regex]::Replace($s, '(?i)hf_[A-Za-z0-9]{16,}', '[REDACTED_HF_TOKEN]')
    $s = [regex]::Replace($s, '(?i)([A-Z]:\\Users\\)[^\\]+', '$1[USER]')
    return $s
}
function Section([string]$Name) { Add-Line ''; Add-Line ('=' * 72); Add-Line $Name; Add-Line ('=' * 72) }

# Locate the known installation path from the user's diagnostic report, with safe fallbacks.
$candidates = @('D:\LocalAI-Studio', (Join-Path $env:LOCALAPPDATA 'LocalAI-Studio'), (Join-Path $env:USERPROFILE 'LocalAI-Studio'))
$Root = $null
foreach ($candidate in $candidates) { if ($candidate -and (Test-Path (Join-Path $candidate 'app.py'))) { $Root = $candidate; break } }
if (-not $Root) {
    Add-Line 'INSTALLATION ROOT NOT FOUND.'
    Add-Line ('Checked: ' + ($candidates -join '; '))
} else { Add-Line ('Install root: ' + (Safe-Text $Root)) }
Add-Line ('Diagnostic package: ' + $PackageRoot)
Add-Line ('Generated: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss K'))
Add-Line 'This is a read-only diagnostic. It does not edit the application, model files, outputs, videos, settings, secrets, or database.'

# Windows/system inventory (no serial numbers, product keys, or environment-variable values).
$Sys = New-Object System.Collections.Generic.List[string]
$Sys.Add('LOCALAI STUDIO - WINDOWS HOST INVENTORY')
$Sys.Add((Get-Date -Format 'yyyy-MM-dd HH:mm:ss K'))
try {
    $os = Get-CimInstance Win32_OperatingSystem
    $Sys.Add(('OS: {0} | Version {1} | Build {2} | Architecture {3}' -f $os.Caption,$os.Version,$os.BuildNumber,$os.OSArchitecture))
    $Sys.Add(('RAM: {0:N1} GB total | {1:N1} GB free' -f ($os.TotalVisibleMemorySize/1MB),($os.FreePhysicalMemory/1MB)))
} catch { $Sys.Add(('OS/RAM query failed: ' + (Safe-Text $_.Exception.Message))) }
try { $cpu=Get-CimInstance Win32_Processor | Select-Object -First 1; $Sys.Add(('CPU: {0} | Cores {1} | Threads {2}' -f $cpu.Name,$cpu.NumberOfCores,$cpu.NumberOfLogicalProcessors)) } catch { $Sys.Add(('CPU query failed: ' + (Safe-Text $_.Exception.Message))) }
try {
    $gpus=Get-CimInstance Win32_VideoController
    foreach($gpu in $gpus) { $Sys.Add(('GPU: {0} | Driver {1} | Adapter RAM reported {2}' -f $gpu.Name,$gpu.DriverVersion,$gpu.AdapterRAM)) }
} catch { $Sys.Add(('GPU query failed: ' + (Safe-Text $_.Exception.Message))) }
try {
    foreach($d in (Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3")) { $Sys.Add(('DISK {0}: {1:N1} GB total | {2:N1} GB free' -f $d.DeviceID,($d.Size/1GB),($d.FreeSpace/1GB))) }
} catch { $Sys.Add(('Disk query failed: ' + (Safe-Text $_.Exception.Message))) }
$Sys.Add('')
$Sys.Add('Relevant environment variables: presence only; values intentionally hidden.')
foreach($name in @('OLLAMA_HOST','OLLAMA_MODELS','HF_HOME','OPENVINO_CACHE_DIR','LTX_API_KEY','HF_TOKEN','HUGGINGFACE_HUB_TOKEN')) {
    $value=[Environment]::GetEnvironmentVariable($name)
    $Sys.Add(($name + ': ' + $(if($value){'SET'}else{'not set'})))
}
$Sys.Add('')
$Sys.Add('Known Ollama model-store folders:')
$ollamaStores = @('D:\LocalAI\Models')
if ($env:OLLAMA_MODELS) { $ollamaStores += $env:OLLAMA_MODELS }
foreach($store in ($ollamaStores | Select-Object -Unique)) {
    if (Test-Path $store) {
        try { $entries=Get-ChildItem -LiteralPath $store -Force -ErrorAction SilentlyContinue; $names=@($entries | Select-Object -First 20 -ExpandProperty Name); $Sys.Add(('Ollama store PRESENT: {0} | top-level entries {1} | names {2}' -f $store,$entries.Count,($names -join ', '))) }
        catch { $Sys.Add(('Ollama store PRESENT but could not enumerate: ' + (Safe-Text $store))) }
    } else { $Sys.Add(('Ollama store not found: ' + (Safe-Text $store))) }
}
try { $svc=Get-Service -Name 'Ollama' -ErrorAction Stop; $Sys.Add(('Ollama Windows service: ' + $svc.Status)) } catch { $Sys.Add('Ollama Windows service: not registered as a Windows service (may run per-user).') }
$Sys.Add('')
$Sys.Add('Relevant processes (no command lines or secret arguments collected):')
try {
    $procs=Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(python|pythonw|ollama|msedge|chrome)\.exe$' }
    foreach($p in $procs) { $exe=''; if($p.ExecutablePath){$exe=Split-Path $p.ExecutablePath -Leaf}; $Sys.Add(('PID {0} | {1} | {2}' -f $p.ProcessId,$p.Name,$exe)) }
} catch { $Sys.Add(('Process inventory failed: ' + (Safe-Text $_.Exception.Message))) }
$Sys.Add('')
$Sys.Add('TCP listeners (local ports only):')
try {
    $listeners=Get-NetTCPConnection -State Listen -ErrorAction Stop | Where-Object { ($_.LocalPort -ge 7865 -and $_.LocalPort -le 7895) -or $_.LocalPort -eq 11434 }
    if($listeners){ foreach($l in $listeners){$Sys.Add(('127/local port {0} | PID {1}' -f $l.LocalPort,$l.OwningProcess))} } else {$Sys.Add('No listener found on 7865-7895 or 11434.')}
} catch {
    foreach($port in (@(7865..7895)+@(11434))) {
        $client=New-Object System.Net.Sockets.TcpClient
        try { $ar=$client.BeginConnect('127.0.0.1',[int]$port,$null,$null); if($ar.AsyncWaitHandle.WaitOne(80)){try{$client.EndConnect($ar);$Sys.Add(('Port {0}: LISTENING' -f $port))}catch{}} } finally {$client.Close()}
    }
}
[System.IO.File]::WriteAllLines($SystemReport,$Sys,[System.Text.Encoding]::UTF8)

# Parse every installed PowerShell script without executing it.
$PsParseReport = Join-Path $OutDir 'powershell-script-parse.txt'
$PsParseLines = New-Object System.Collections.Generic.List[string]
$PsParseLines.Add('WINDOWS POWERSHELL 5.1 SCRIPT PARSE CHECK')
if ($Root) {
    $psFiles = @(Get-ChildItem -LiteralPath $Root -Filter '*.ps1' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch '\\.venv\\|\\models\\|\\cache\\|\\outputs\\|\\videos\\' })
    $psFiles += Get-Item -LiteralPath $MyInvocation.MyCommand.Path
    $psFiles = $psFiles | Sort-Object -Property FullName -Unique
    foreach($f in $psFiles) {
        try {
            $tokens=$null; $parseErrors=$null
            [void][System.Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$tokens,[ref]$parseErrors)
            if ($parseErrors.Count -eq 0) { $PsParseLines.Add(('PASS: ' + $f.Name)) }
            else {
                $PsParseLines.Add(('FAIL: ' + $f.Name))
                foreach($e in $parseErrors) { $PsParseLines.Add(('  Line {0}, Column {1}: {2}' -f $e.Extent.StartLineNumber,$e.Extent.StartColumnNumber,(Safe-Text $e.Message))) }
            }
        } catch { $PsParseLines.Add(('FAIL: {0}: {1}' -f $f.Name,(Safe-Text $_.Exception.Message))) }
    }
    if (-not $psFiles) { $PsParseLines.Add('WARN: no .ps1 files found under install root.') }
} else { $PsParseLines.Add('SKIP: installation root not found.') }
[System.IO.File]::WriteAllLines($PsParseReport,$PsParseLines,[System.Text.Encoding]::UTF8)

# Probe the user's existing application listener without starting or stopping it.
$InstalledServerLines = New-Object System.Collections.Generic.List[string]
$InstalledServerLines.Add('INSTALLED LOCALAI SERVER HEALTH PROBE')
$foundHealthy = $false
foreach($port in 7865..7895) {
    try {
        $health = Invoke-RestMethod -Uri ("http://127.0.0.1:{0}/healthz" -f $port) -TimeoutSec 2 -ErrorAction Stop
        if ($health.app -eq 'LocalAI Studio' -and $health.ok -eq $true) { $InstalledServerLines.Add(('HEALTHY: port {0} | version {1}' -f $port,$health.version)); $foundHealthy=$true }
        else { $InstalledServerLines.Add(('HTTP responding but not LocalAI Studio: port {0}' -f $port)) }
    } catch { }
}
if (-not $foundHealthy) { $InstalledServerLines.Add('No running LocalAI Studio health endpoint found on ports 7865-7895. The isolated TCP smoke test will still be attempted by Python.') }
$InstalledServerReport = Join-Path $OutDir 'installed-server-health.txt'
[System.IO.File]::WriteAllLines($InstalledServerReport,$InstalledServerLines,[System.Text.Encoding]::UTF8)

# Python/application checks.
Section 'PYTHON AND APPLICATION DIAGNOSTICS'
if (-not $Root) {
    Add-Line 'SKIPPED: no installation root was found. Host inventory is still included.'
} else {
    $Python = Join-Path $Root '.venv\Scripts\python.exe'
    if (-not (Test-Path $Python)) {
        $Python = (Get-Command python.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source)
        if (-not $Python) { $Python = (Get-Command py.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source) }
    }
    if ($Python -and (Test-Path $Python)) {
        Add-Line ('Python executable: ' + (Safe-Text $Python))
        $script = Join-Path $PackageRoot 'diagnose_full.py'
        if (Test-Path $script) {
            & $Python $script --root $Root --out $OutDir 1> $PyOut 2> $PyErr
            $PyExit = $LASTEXITCODE
            Add-Line ('Python diagnostic exit code: ' + $PyExit)
            if (Test-Path $PyOut) { Get-Content $PyOut -Tail 40 | ForEach-Object { Add-Line (Safe-Text $_) } }
            if ((Test-Path $PyErr) -and ((Get-Item $PyErr).Length -gt 0)) { Add-Line 'Python diagnostic stderr:'; Get-Content $PyErr -Tail 100 | ForEach-Object { Add-Line (Safe-Text $_) } }
        } else { Add-Line 'FAIL: diagnose_full.py is missing from the extracted diagnostic package.' }
    } else { Add-Line 'FAIL: no Python executable found (neither the project .venv nor python.exe/py.exe).' }
}

# Sanitized recent logs: include error-bearing context, not settings/secrets/database contents.
$LogLines = New-Object System.Collections.Generic.List[string]
$LogLines.Add('SANITIZED RECENT LOG EXCERPTS')
$LogLines.Add('Secret-looking values and Windows user names are redacted. Logs may still contain prompts or file names; review before sharing.')
$candidateLogDirs = @()
if ($Root -and (Test-Path (Join-Path $Root 'logs'))) { $candidateLogDirs += (Join-Path $Root 'logs') }
if ($env:LOCALAPPDATA -and (Test-Path (Join-Path $env:LOCALAPPDATA 'Ollama\server.log'))) { $candidateLogDirs += (Join-Path $env:LOCALAPPDATA 'Ollama') }
if ($env:USERPROFILE -and (Test-Path (Join-Path $env:USERPROFILE '.ollama\server.log'))) { $candidateLogDirs += (Join-Path $env:USERPROFILE '.ollama') }
$allLogFiles = @()
foreach($dir in $candidateLogDirs) {
    $allLogFiles += Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in @('.log','.txt') -or $_.Name -match 'runtime|diagnostic|repair|upgrade|install|startup|server' }
}
$logFiles = $allLogFiles | Sort-Object LastWriteTime -Descending | Select-Object -First 22
if ($logFiles) {
    foreach($f in $logFiles) {
        $LogLines.Add(''); $LogLines.Add(('--- {0} | {1} bytes | modified {2} ---' -f $f.Name,$f.Length,$f.LastWriteTime))
        try { Get-Content -LiteralPath $f.FullName -Tail 140 -ErrorAction Stop | ForEach-Object { $LogLines.Add((Safe-Text $_)) } }
        catch { $LogLines.Add(('Could not read log: ' + (Safe-Text $_.Exception.Message))) }
    }
} else { $LogLines.Add('No application or Ollama logs found in known locations.') }
[System.IO.File]::WriteAllLines($LogReport,$LogLines,[System.Text.Encoding]::UTF8)

# Compose the top-level readable report.
[System.IO.File]::WriteAllLines($Report,$Lines,[System.Text.Encoding]::UTF8)
Add-Content -LiteralPath $Report -Value (Get-Content -LiteralPath $SystemReport -Raw -Encoding UTF8)
Add-Content -LiteralPath $Report -Value (Get-Content -LiteralPath $LogReport -Raw -Encoding UTF8)
Add-Content -LiteralPath $Report -Value "`r`n`r`n"
Add-Content -LiteralPath $Report -Value (Get-Content -LiteralPath $PsParseReport -Raw -Encoding UTF8)
Add-Content -LiteralPath $Report -Value "`r`n`r`n"
Add-Content -LiteralPath $Report -Value (Get-Content -LiteralPath $InstalledServerReport -Raw -Encoding UTF8)
if (Test-Path (Join-Path $OutDir 'project-diagnostic.txt')) {
    Add-Content -LiteralPath $Report -Value "`r`n`r`n"
    Add-Content -LiteralPath $Report -Value (Get-Content -LiteralPath (Join-Path $OutDir 'project-diagnostic.txt') -Raw -Encoding UTF8)
}

# Create a single archive beside the runner so the user only has one file to send back.
$Archive = Join-Path $PackageRoot ("LocalAI-Studio-Full-Diagnostic-" + $Stamp + '.zip')
try {
    if (Test-Path $Archive) { Remove-Item $Archive -Force }
    Compress-Archive -Path (Join-Path $OutDir '*') -DestinationPath $Archive -CompressionLevel Optimal -Force
    Add-Line ('Diagnostic archive: ' + $Archive)
} catch { Add-Line ('ARCHIVE ERROR: ' + (Safe-Text $_.Exception.Message)); Add-Line ('Reports remain in: ' + $OutDir) }

Write-Host ''
Write-Host 'LOCALAI STUDIO FULL DIAGNOSTIC FINISHED' -ForegroundColor Cyan
Write-Host ('Report: ' + $Report) -ForegroundColor Green
Write-Host ('Archive: ' + $Archive) -ForegroundColor Green
Write-Host 'No application, model, output, video, settings, or database files were changed.' -ForegroundColor Yellow
Read-Host 'Press Enter to close'
